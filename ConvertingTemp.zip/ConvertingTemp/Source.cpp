/*
* Landon Johnston
* CS 210
* Reading and Writing Files
* 07/23/2021
*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

class Temperature {
public:
    void SetLocation(string filePlace) {placeName = filePlace;} // Used to set the location read in the file
    void SetTemp(int fileTemp) {currentTemperature = fileTemp;} // Used to set the Temperature read in the file
    void ReadFile(vector<Temperature>& reviewTemp); // Declares the function
    void DisplayFile(const vector<Temperature>& reviewTemp); // Declares the function
    void FarhenhitToCelcius(const vector<Temperature>& reviewTemp); // Declares the function

    string GetLocation() const {return placeName;} // Declares the function
    int GetTemperature() const {return currentTemperature;} // Declares the function

private:
    string placeName = "NoName";
    int currentTemperature = -1;
};
//Prints the contents of the file "FahrenheitTemperature.txt"
void Temperature::DisplayFile(const vector<Temperature>& reviewTemp) {
   unsigned int i;
   cout << "Reading contents of \"FahrenheitTemperature.txt\"" << endl;
   cout << endl;
   cout << reviewTemp.size();
    for (i = 0; i < reviewTemp.size(); ++i) {  //Iterates through the vector and prints the location and the temperature
        
        cout << "Location: " << reviewTemp.at(i).GetLocation() << " ";
        cout << "Temperature " << reviewTemp.at(i).GetTemperature() << endl;
        cout << endl;
    }
}
//Used to Read the file "FahrenheitTemperature.txt"
void Temperature::ReadFile(vector<Temperature>& reviewTemp) {
    string placeName;  // Data value from file
    int currentTemperature;  // Data value from file

    ifstream inFS; //Input file stream        
    inFS.open("FahrenheitTemperature.txt"); // opens the file "FahrenheitTemperature.txt"

    while (!inFS.eof()) { // stops when the end of the file is reached
        Temperature currReview;
        inFS >> placeName;
        inFS >> currentTemperature;

        if (!inFS.fail()) { // sets the data if no errors exist reading the file
            currReview.SetLocation(placeName); // sets the location read from the file
            currReview.SetTemp(currentTemperature); // set the temperature from the file
            reviewTemp.push_back(currReview); // adds each set location and temp to the vector currReveiw
        }
    }
    inFS.close(); // Closed file since we read and stored all the contents

}

// converts THe file content temperature from farhenheit to  celcius
void Temperature::FarhenhitToCelcius(const vector<Temperature>& reviewTemp) {
    ofstream outFS; // output to file stream
    outFS.open("CelsiusTemperature.txt"); //opens the file "CelsiusTemperature.txt"

    double celcius; // Data value used to convert
    double tempconversion;  // temperary Data value used to convert
    unsigned int i;
    cout.precision(2);  // sets the decimal point to two intgers
    
    
    cout << endl << endl;
    cout << "Converting Fahrenheit to Celcius" << endl;
    cout << endl;

    for (i = 0; i < reviewTemp.size(); ++i) { // itterates over the vector reveiw temp
        tempconversion = reviewTemp.at(i).GetTemperature(); 
        celcius = (tempconversion - 32) * 5 / 9; // conversion fahrenheit to celcius
        outFS << reviewTemp.at(i).GetLocation(); // writes the location to "CelsiusTemperature.txt"
        outFS << " " << fixed << celcius<< endl; // write the converted temp to "CelsiusTemperature.txt"
                
        cout << endl;
        cout << "Location: " << reviewTemp.at(i).GetLocation(); //Prints out the contents of "CelsiusTemperature.txt"
        cout << " Temperature: " << fixed << celcius << endl;  //Prints out the contents of "CelsiusTemperature.txt"
    }
    outFS.close(); // Closed file since we converted all the contents and wote to "CelsiusTemperature.txt"
}


int main() {
    vector<Temperature> reviewTemp; // creates vector  reviewTemp
    Temperature temp; // intializes a new object
    temp.ReadFile(reviewTemp); // starts the readfile function using the vector
    temp.DisplayFile(reviewTemp); // displays the contents of the file
    temp.FarhenhitToCelcius(reviewTemp); // converts the file temp to celcius and writes to a new file
}